//
//  ViewController.swift
//  2
//
//  Created by iOS TeamLead on 2/19/19.
//  Copyright © 2019 iOS TeamLead. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

   
       /////////////GET/////////////////
        Alamofire.request(url, method: .get, encoding: JSONEncoding.default)
            .downloadProgress(queue: DispatchQueue.global(qos: .utility)) { progress in
                print("Progress: \(progress.fractionCompleted)")
            }
            .validate { request, response, data in
                // Custom evaluation closure now includes data (allows you to parse data to dig out error messages if necessary)
                return .success
            }
            .responseJSON { response in
                print(response)
        }
    
      ///////////////Post////////////////////
    Alamofire.request(url, method: .post, parameters: parameter,encoding: JSONEncoding.default)
    .downloadProgress(queue: DispatchQueue.global(qos: .utility)) { progress in
    print("Progress: \(progress.fractionCompleted)")
    }
    .validate { request, response, data in
    // Custom evaluation closure now includes data (allows you to parse data to dig out error messages if necessary)
    return .success
    }
    .responseJSON { response in
    print(response)
    }
    //////////////////////

}

