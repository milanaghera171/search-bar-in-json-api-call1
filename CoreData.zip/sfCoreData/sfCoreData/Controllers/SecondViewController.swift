//
//  SecondViewController.swift
//  sfCoreData
//
//  Created by agile on 29/11/18.
//  Copyright © 2018 ON. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    //MARK:- PROPERTIES
    @IBOutlet weak var tablevVew1: UITableView!
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        tablevVew1.dataSource = self
        tablevVew1.delegate = self
        
        let nibName1 = UINib(nibName: "TableViewCellCustom", bundle: nil)
        tablevVew1.register(nibName1, forCellReuseIdentifier: "Cell")
    }
    
  
}

//MARK:- EXTENSION UITableViewDataSource
extension SecondViewController : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return appDelegate.arrayGloble.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tablevVew1.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TableViewCellCustom
        
        let dateFormateDate = appDelegate.arrayGloble[indexPath.row].date
        let stringFormateDate = "\(dateFormateDate)"
        
        cell.lblName.text = appDelegate.arrayGloble[indexPath.row].name
        cell.lblIdPerson.text = appDelegate.arrayGloble[indexPath.row].idPerson
        cell.lblDate.text = stringFormateDate
        cell.layer.borderWidth = 1
        cell.layer.cornerRadius = 17
        cell.clipsToBounds = true
        
        
        return cell
    }
}

//MARK:- EXTENSION UITableViewDelegate
extension SecondViewController : UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    
    
}
