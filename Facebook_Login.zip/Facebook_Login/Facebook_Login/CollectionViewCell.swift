//
//  CollectionViewCell.swift
//  Facebook_Login
//
//  Created by iOS TeamLead on 3/13/19.
//  Copyright © 2019 iOS TeamLead. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imgView: UIImageView!
}
