//
//  ViewController.swift
//  Facebook_Login
//
//  Created by iOS TeamLead on 3/7/19.
//  Copyright © 2019 iOS TeamLead. All rights reserved.
//

import UIKit
import Pods_Facebook_Login
import FBSDKLoginKit
import FBSDKCoreKit
import FBSDKShareKit
import Foundation
import SwiftyJSON
import SDWebImage

//Email:-  open_wicbxyj_user@tfbnw.net
//Password:- stegowl@123
class ViewController: UIViewController {
    @IBOutlet weak var clview: UICollectionView!
     var array = NSMutableArray()
    @IBOutlet weak var btnlogin: UIButton!
//    var accessToken: FBSDKAccessToken?
//    let baseUrl = "https://graph.facebook.com/v2.4/"
//    init(){
//        accessToken = FBSDKAccessToken.current()
//    }
    override func viewDidLoad() {
        super.viewDidLoad()
      
//      accessToken = FBSDKAccessToken.current()
        // Do any additional setup after loading the view, typically from a nib.
    }


    @IBAction func btnLogin(_ sender: Any) {
//        btnlogin.addTarget(self, action: #selector(loginButtonClicked), for: .touchUpInside)
       

        let login = FBSDKLoginManager()
        login.logIn(withReadPermissions: ["public_profile", "email", "user_friends","user_photos"], handler: { (result, error) -> Void in
            if (error != nil)
            {
                print("Process error")
            }
            else if result!.isCancelled
            {
                print("Cancelled")
            }
            else
            {
                // SVProgressHUD.showWithStatus("Loading")
                print(result!)
                print("Logged in")
                self.fetchProfile()
//                 fetchAlbum
            }
        })
//        self.accessToken = FBSDKAccessToken.current()
    }

    //FB Login Function
    
    
    
    
    
    
    
    
    
    func fetchProfile()
    {
        let parameters =  ["fields":"images"]

        FBSDKGraphRequest(graphPath: "me/photos/uploaded", parameters: parameters).start { (connection, user, Err) in
            if Err != nil
            {
                print(Err!)
                return
            }
            print(user!)
            
            let dic = user as! NSDictionary
            
           
             let data1 = dic["data"] as! NSArray
             let arr = data1.mutableCopy()as? NSMutableArray
            print(arr!)
           
            for data in arr!{
//                let aa = (arr?.object(at: 1) as AnyObject).value(forKey: "images") as! NSArray
            print("data\(data)")
            }
             self.array = data1.mutableCopy() as! NSMutableArray
          self.clview.reloadData()
        }

    }

  
}
    

extension ViewController:UICollectionViewDataSource,UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return array.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
         let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for: indexPath) as! CollectionViewCell
        
         let aa = (array.object(at:1) as AnyObject).value(forKey: "images") as! NSArray
         let arr = aa.mutableCopy() as! NSMutableArray

         let data = (arr.object(at: indexPath.row) as AnyObject).value(forKey: "source") as! String
        print("data:- \(data)")
//        let img_url = "http://durisimomobileapps.net/flowactivo/storage/uploads/LitoKirino_1544259039.jpg"
//        print(img_url)
        //cell.imgView.sd_setImage(with: img_url, placeholderImage: UIImage(named: "2"))
//        cell.imgView.sd_setImage(with: URL(string: img_url), placeholderImage: UIImage(named: "2"), options: .continueInBackground)
        return cell
    }
    
    
}

