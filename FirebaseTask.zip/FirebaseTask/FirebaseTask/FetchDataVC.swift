//
//  FetchDataVC.swift
//  FirebaseTask
// https://www.simplifiedios.net/firebase-realtime-database-tutorial/
//  Created by iOS TeamLead on 4/1/19.
//  Copyright © 2019 iOS TeamLead. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
class userData {
    
    var id: String?
    var name: String?
    var genre: String?
    
    init(id: String?, name: String?, genre: String?){
        self.id = id
        self.name = name
        self.genre = genre
    }
}
class FetchDataVC: UIViewController {
     var data = [userData]()
    @IBOutlet weak var tblData: UITableView!
    var Fname = NSMutableArray()
//    var Lname = NSMutableDictionary()
    override func viewDidLoad() {
        super.viewDidLoad()
       tblData.dataSource = self
       fatchFIRData()
    }
    

    func fatchFIRData(){
       
        let ref = Database.database().reference(withPath: "userData")
        ref.observeSingleEvent(of: .value, with: { snapshot in
            
            if !snapshot.exists() { return }
            
            
              print(snapshot)
//          self.Lname = (snapshot.value as! NSDictionary).mutableCopy() as! NSMutableDictionary
//            self.Fname = (snapshot.value as! NSArray).mutableCopy() as! NSMutableArray
          let data =  (snapshot.value as! NSDictionary).mutableCopy() as! NSMutableDictionary
            print(data)
            
            for arr in data{
                let aa = arr.value
                print(aa)
                self.Fname.add(aa)
            }
            self.tblData.reloadData()

        })

    }

}
extension FetchDataVC:UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Fname.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell") as! TableViewCell
      
    
       
        print(Fname)
        cell.lblFname.text =  ((Fname.object(at: indexPath.row)as AnyObject).value(forKey: "Fname") as? String)
        cell.lblLname.text = ((Fname.object(at: indexPath.row)as AnyObject).value(forKey: "Lname") as? String)
        return cell
    }
    
    
}
