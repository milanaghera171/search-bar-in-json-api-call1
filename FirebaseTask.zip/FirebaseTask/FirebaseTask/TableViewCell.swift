//
//  TableViewCell.swift
//  FirebaseTask
//
//  Created by iOS TeamLead on 4/1/19.
//  Copyright © 2019 iOS TeamLead. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {
    @IBOutlet weak var lblFname: UILabel!
    
    @IBOutlet weak var lblLname: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
