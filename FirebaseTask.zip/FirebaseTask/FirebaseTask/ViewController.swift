//
//  ViewController.swift
//  FirebaseTask
//
//  Created by iOS TeamLead on 3/29/19.
//  Copyright © 2019 iOS TeamLead. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class ViewController: UIViewController {
  
    @IBOutlet weak var txtFname: UITextField!
    @IBOutlet weak var txtLname: UITextField!
    var databaseRefer : DatabaseReference!
    var databaseHandle : DatabaseHandle!
//  var ref = DatabaseReference.init()
    override func viewDidLoad() {
//        super.viewDidLoad()
//        self.saveFIRData()
      //  FirebaseApp.configure()
         databaseRefer = Database.database().reference().child("userData");
        //getting a reference to the node artists
       
     
    }

    func addArtist(){
        //generating a new key inside artists node
        //and also getting the generated key
        
        if txtFname.text == "" {
            let alertView:UIAlertView = UIAlertView()
            alertView.message = "Please enter Fname"
            alertView.delegate = self
            alertView.addButton(withTitle: "OK")
            alertView.show()
        }else if txtLname.text == ""{
            let alertView:UIAlertView = UIAlertView()
            alertView.message = "Please enter Lname"
            alertView.delegate = self
            alertView.addButton(withTitle: "OK")
            alertView.show()
        }else{
        let key = databaseRefer.childByAutoId().key
        
        //creating artist with the given values
        let artist = ["id":key,
                      "Fname": txtFname.text! as String,
                      "Lname": txtLname.text! as String
        ]
        
        //adding the artist inside the generated unique key
        databaseRefer.child(key!).setValue(artist)
        txtFname.text = ""
        txtLname.text = ""
        }
        //displaying message
//        labelMessage.text = "Artist Added"
    }
        
        
    func saveFIRData(){
        self.databaseRefer = Database.database().reference()
         self.databaseRefer.child("User1").childByAutoId().setValue("name")
        self.databaseRefer.child("name").childByAutoId().setValue(txtFname.text)

        self.databaseHandle = self.databaseRefer.child("User1").observe(.childAdded, with: { (data) in
            let name : String = (data.value as? String)!
            debugPrint(name)
        })
//        self.databaseHandle = self.databaseRefer.child("Lname").observe(.childAdded, with: { (data) in
//            let name : String = (data.value as? String)!
//            debugPrint(name)
//        })
        txtFname.text = ""
        txtLname.text = ""
    }
    @IBAction func btnSaveFIRData(_ sender: UIButton) {
//         saveFIRData()
        addArtist()
    }
    @IBAction func btnFatchFIRData(_ sender: UIButton) {
        let fetchVC = storyboard?.instantiateViewController(withIdentifier: "FetchDataVC") as! FetchDataVC
        navigationController?.pushViewController(fetchVC, animated: true)
     
        
    }
    
}
