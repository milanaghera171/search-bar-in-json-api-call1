//
//  ListViewController.swift
//  M-Core Data in Yogesh Patel
//
//  Created by agilemac-74 on 28/12/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit
protocol DataPass{
    func data(object:[String:String],index:Int,isEdit:Bool)
}

class ListViewController: UIViewController {
    @IBOutlet var tblTableViewCell: UITableView!
    
    var student = [Student]()
    var delegate:DataPass!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblTableViewCell.tableFooterView = UIView()
        tblTableViewCell.delegate = self
        tblTableViewCell.dataSource = self
       student = DatabaseHelper.shareInstance.getStudentData()
//
        
//        let topColor = UIColor.blue
//        let bottomColor = UIColor.black
        
//        self.tblTableViewCell.backgroundColor = topColor
        self.tblTableViewCell.tableFooterView = UIView(frame: CGRect.zero)
        let footerView = UIView(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: 0))
//        footerView.backgroundColor = bottomColor
        self.tblTableViewCell.tableFooterView?.addSubview(footerView)
        
    }
   
    func alert(title:String,mes:String,delegate:AnyObject){
        let alert = UIAlertView()
        alert.title = title
        alert.message = mes
        alert.addButton(withTitle: "OK")
        alert.delegate = DatabaseHelper.shareInstance
        alert.show()
    }
}
//MARK:- Table View Delegate
extension ListViewController:UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            student = DatabaseHelper.shareInstance.deleteData(index: indexPath.row)
            self.tblTableViewCell.deleteRows(at: [indexPath], with: .automatic)
        alert(title: "Delete Successfully", mes: "", delegate: self)
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        let dict = ["name":student[indexPath.row].name,"address":student[indexPath.row].address,"city":student[indexPath.row].city,"mobile":student[indexPath.row].mobile]
        
        delegate.data(object: dict as![String:String], index: indexPath.row, isEdit: true)
        
        self.navigationController?.popViewController(animated: true)
    }
    
}
//MARK:- Table View DataSource
extension ListViewController:UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return student.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblTableViewCell.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath)as! TableViewCell
        
            cell.student = student[indexPath.row]
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
        
    }
    
}

