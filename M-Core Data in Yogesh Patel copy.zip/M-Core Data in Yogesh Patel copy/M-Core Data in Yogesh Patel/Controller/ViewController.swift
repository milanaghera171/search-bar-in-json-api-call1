//
//  ViewController.swift
//  M-Core Data in Yogesh Patel
//
//  Created by agilemac-74 on 28/12/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit


class ViewController: UIViewController{

    @IBOutlet weak var btnShow: UIButton!
    @IBOutlet weak var btnSave: UIButton!
    @IBOutlet var txtName: UITextField!
    @IBOutlet var txtAddress: UITextField!
    @IBOutlet var txtCity: UITextField!
    @IBOutlet var txtMobile: UITextField!
    var i = Int()
    var isUpdate = Bool()
    override func viewDidLoad() {
        super.viewDidLoad()
        
       txtName.layer.cornerRadius = 15
        txtName.layer.masksToBounds = true
        txtCity.layer.cornerRadius = 15
        txtCity.layer.masksToBounds = true
        txtMobile.layer.cornerRadius = 15
        txtMobile.layer.masksToBounds = true
        txtAddress.layer.cornerRadius = 15
        txtAddress.layer.masksToBounds = true
        btnSave.layer.cornerRadius = 20
        btnSave.layer.masksToBounds = true
        btnShow.layer.cornerRadius = 20
        btnShow.layer.masksToBounds = true
    }
//MARK:- Button Show Data
   
    @IBAction func btnShowClick(_ sender: Any) {
        let listVC = self.storyboard?.instantiateViewController(withIdentifier: "ListViewController")as! ListViewController
      
        listVC.delegate = self
        
        self.navigationController?.pushViewController(listVC, animated: true)
    }
//MARK:- Button Sava Data
    @IBAction func btnSave(_ sender: Any) {
        if txtName.text == ""{
            alert(title: "Enter Name", mes: "Plz Enter Name", delegate: self)
        }else if txtAddress.text == "" {
            alert(title: "Enter Address", mes: "Plz Enter Address", delegate: self)
        }else if txtCity.text == ""{
            alert(title: "Enter City", mes: "Plz Enter City", delegate: self)
        }else if txtMobile.text == ""{
            alert(title: "Enter Mobile", mes: "Plz Enter Mobile", delegate: self)
            
        }else{

        let dict:[String:String] = ["name":txtName.text!,"address":txtAddress.text!,"city":txtCity.text!,"mobile":txtMobile.text!]
      alert(title: "Successfully", mes:"", delegate: self)
//        let dict = ["name":txtName.text,"address":txtAddress.text,"city":txtCity.text,"mobile":txtMobile.text]
            if  isUpdate {
                DatabaseHelper.shareInstance.editData(object:dict , i: i)
                 alert(title: "Update Successfully", mes:"", delegate: self)
            }else{
                DatabaseHelper.shareInstance.save(object: dict )
                
                
            }
            txtName.text = ""
            txtAddress.text = ""
            txtCity.text = ""
            txtMobile.text = ""
        }
    }
//MARK:- Alert control
    func alert(title:String,mes:String,delegate:AnyObject){
        let alert = UIAlertView()
        alert.title = title
        alert.message = mes
        alert.addButton(withTitle: "OK")
        alert.delegate = DatabaseHelper.shareInstance
        alert.show()
    }
}
//MARK:- Edite Data Body
extension ViewController:DataPass{
    func data(object: [String : String], index: Int, isEdit: Bool) {
        txtName.text = object["name"]
        txtAddress.text = object["address"]
        txtCity.text = object["city"]
        txtMobile.text = object["mobile"]
        i = index
        isUpdate = isEdit
    }
    
    
}

