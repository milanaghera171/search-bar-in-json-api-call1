//
//  Student+CoreDataClass.swift
//  M-Core Data in Yogesh Patel
//
//  Created by agilemac-74 on 28/12/18.
//  Copyright © 2018 Agile. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Student)
public class Student: NSManagedObject {

}
