//
//  TableViewCell.swift
//  M-Core Data in Yogesh Patel
//
//  Created by agilemac-74 on 28/12/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

     @IBOutlet var lblName: UILabel!
     @IBOutlet var lblAddress: UILabel!
     @IBOutlet var lblCity: UILabel!
     @IBOutlet var lblMobile: UILabel!
    
    var student:Student!{
        didSet{
            lblName.text = "   Name:  " + student.name!
            lblAddress.text = "   Address:  " + student.address!
            lblCity.text = "   City:  " + student.city!
            lblMobile.text = "   Mobile:  " + student.mobile!
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
       
        lblCity.layer.cornerRadius = 10
        lblCity.layer.masksToBounds = true
        lblName.layer.cornerRadius = 10
        lblName.layer.masksToBounds = true
        lblMobile.layer.cornerRadius = 10
        lblMobile.layer.masksToBounds = true
        lblAddress.layer.cornerRadius = 10
        lblAddress.layer.masksToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

     
    }

}
