//
//  Fetch Data ViewController.swift
//  M-CoreData
//
//  Created by agilemac-74 on 30/11/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class Fetch_Data_ViewController: UIViewController {

    @IBOutlet var tableview: UITableView!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}
