//
//  TableViewCell.swift
//  M-CoreData
//
//  Created by agilemac-74 on 30/11/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

  
    @IBOutlet var lblName: UILabel!
    @IBOutlet var lblidPerson: UILabel!
    @IBOutlet var lblbirthDate: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
