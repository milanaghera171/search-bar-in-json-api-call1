//
//  ViewController.swift
//  M-CoreData
//
//  Created by agilemac-74 on 28/11/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet var txtname: UITextField!
    @IBOutlet var txtid: UITextField!
    
    @IBOutlet var txtnameupdate: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        txtid.keyboardType = .numberPad
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnInsertPressed(_ sender: UIButton) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{
            return
        }
        let managedObjectContext = appDelegate.persistentContainer.viewContext
        
        let personEntity = NSEntityDescription.entity(forEntityName: "Newperson", in: managedObjectContext)
        let object:NSManagedObject = NSManagedObject.init(entity: personEntity!, insertInto: managedObjectContext)

//        object.setValue("mv", forKey: "name")
//        object.setValue("kkkk", forKey: "idPerson")
//        object.setValue(Date(), forKey: "birthDate")
        
        object.setValue(txtname.text, forKey: "name")
        object.setValue(txtid.text, forKey: "idPerson")
        object.setValue(Date(), forKey: "birthDate")
        txtname.text = ""
        txtid.text = ""
        do{
            try managedObjectContext.save()
        }catch{
            
        }
    }
    
    @IBAction func btnFetchPressed(_ sender: UIButton) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{
            return
        }
        let manageContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest:NSFetchRequest = NSFetchRequest<NSManagedObject>.init(entityName: "Newperson")
        do{
            let data = try manageContext.fetch(fetchRequest)
            for Newperson in data{
                print("/n/n")
                print(Newperson.value(forKey: "idPerson"))
                print(Newperson.value(forKey: "name"))
                print(Newperson.value(forKey: "birthDate"))
            }
        }catch{
            
        }
    
        
        
        
    }
    
    
    @IBAction func btnUpdatePressed(_ sender: UIButton) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{
            return
        }
        let manageContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest:NSFetchRequest = NSFetchRequest<NSManagedObject>.init(entityName: "Newperson")
        do{
            let data = try manageContext.fetch(fetchRequest)
            for Newperson in data{
                if let name = Newperson.value(forKey: "name") as? String{
//                    if name == "mv"{
//                        Person.setValue("mvpatel", forKey: "name")
                    
                        if name == txtname.text{
                            Newperson.setValue(txtnameupdate.text, forKey: "name")
                    }
                }
            }
        }catch{
            
        }
        do{
            try manageContext.save()
        }catch{
            
        }
        
    }
    
    @IBAction func btnDeletePressed(_ sender: UIButton) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{
            return
        }
        let manageContext = appDelegate.persistentContainer.viewContext
        let fetchRequest:NSFetchRequest = NSFetchRequest<NSManagedObject>.init(entityName: "Newperson")
        
        do{
            let data = try manageContext.fetch(fetchRequest)
            for Newperson in data{
                if let name = Newperson.value(forKey:"name") as? String{
//                    if name == "mv"{
                            if name == txtname.text{
                        manageContext.delete(Newperson)
                    }
                }
            }
        }catch{
            
        }
        do{
            try manageContext.save()
        }catch{
            
        }
    }
    
}

