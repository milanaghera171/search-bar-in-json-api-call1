//
//  ViewController.swift
//  M-Inspectable
//
//  Created by agilemac-74 on 18/12/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit
class MyLabel:UILabel{
    @IBInspectable var myColor:UIColor = UIColor.red
//    @IBInspectable var fontColor:UIColor = UIColor.red
    
    
//   @IBInspectable` public var cornerRadius: CGFloat = 2.0 {
//        didSet {
//            self.layer.cornerRadius = self.cornerRadius
//            self.clipsToBounds = true
//        }
//    }
    @IBInspectable var cornerRadius: CGFloat = 0 {
        didSet {
            layer.cornerRadius = cornerRadius
            layer.masksToBounds = cornerRadius > 0
        }
    }
    override func awakeFromNib(){
        super.awakeFromNib()
        self.backgroundColor = myColor
//        self.textColor = fontColor
    }
}

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

