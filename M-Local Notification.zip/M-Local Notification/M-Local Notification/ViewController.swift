//
//  ViewController.swift
//  M-Local Notification
//
//  Created by agilemac-74 on 08/12/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit
import UserNotifications
class ViewController: UIViewController {

    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        }
    func askPermission(){
        
        UNUserNotificationCenter.current().requestAuthorization(options: [.badge, .alert , .sound]){(granted,error) in
            
            if granted {
                self.sepUpLocalNotification()
            }else{
                print("\n\nError : \(String(describing: error?.localizedDescription))")
            }
            
        }
        
    }
    func sepUpLocalNotification() {
        let content = UNMutableNotificationContent()
        content.title = "This is Title"
        content.body = "this is Body"
        content.sound = UNNotificationSound.default()
        
        content.badge = 5
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 60, repeats: false)
        
     let request = UNNotificationRequest(identifier: "identifier_1", content: content, trigger: trigger)
        
        UNUserNotificationCenter.current().add(request){ (err) in
            if err != nil {
                print("\n There was an error while adding notificaion request : \(String(describing: err?.localizedDescription))")
            }else{
                print("\n Request Added Successfully")
            }
            
        }
        UNUserNotificationCenter.current().delegate = self
    }
    @IBAction func btnSetLocalNotification(_ sender: UIButton) {
        
        askPermission()
    }
}
extension ViewController: UNUserNotificationCenterDelegate{
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        print("\n Will Present  Notificaion: \(notification)")
        
        if notification.request.identifier == "identifier_1"{
            completionHandler([.alert, .badge, .sound])
        }else{
            completionHandler([])
        }
    }
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        print("\n Did receive to response of notification :\(response.notification)")
    }
}
