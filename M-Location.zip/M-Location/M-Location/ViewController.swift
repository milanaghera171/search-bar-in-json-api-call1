//
//  ViewController.swift
//  M-Location
//
//  Created by agilemac-74 on 04/12/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController {
  var locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpLocationManager()
       
    }

    func setUpLocationManager(){
       locationManager = CLLocationManager()
        
       locationManager.delegate = self
       locationManager.desiredAccuracy = kCLLocationAccuracyBest
       locationManager.requestAlwaysAuthorization()
    }
    @IBAction func btnStartUpdatingLocationPressed(_ sender: UIButton) {
        locationManager.startUpdatingLocation()
    }
    
    @IBAction func btnStopUpdatingLocationPressed(_ sender: UIButton) {
        locationManager.stopUpdatingLocation()
    }
}
extension ViewController: CLLocationManagerDelegate{
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print("\n Did UpDate Location:\(locations)")
        
    }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("\n Did failed With Error:\(error.localizedDescription)")
    }
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        print("\n Did Change Authorization: \(status.userFriendlyName)")
    }
}
extension CLAuthorizationStatus{
    var userFriendlyName:String{
        switch self{
            
        case.notDetermined:
            return "notDetermined";
            
        case .restricted:
            return "restricted";
            
        case .denied:
            return "denied";
            
        case .authorizedAlways:
            return "authorizedAlways";
            
        case .authorizedWhenInUse:
            return "authorizedWhenInUse";
        }
    }
}
