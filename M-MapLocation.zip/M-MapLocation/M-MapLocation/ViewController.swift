//
//  ViewController.swift
//  M-MapLocation
//

//  Created by agilemac-74 on 06/12/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController {
    @IBOutlet var mapView: MKMapView!
    var locationManager = CLLocationManager()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        mapView.showsUserLocation = true
       if CLLocationManager.locationServicesEnabled() == true {
        
            if CLLocationManager.authorizationStatus() == .restricted ||
               CLLocationManager.authorizationStatus() == .denied ||
               CLLocationManager.authorizationStatus() == .notDetermined{
               locationManager.requestWhenInUseAuthorization()
        }
           locationManager.desiredAccuracy = 1.0
           locationManager.delegate = self
//           locationManager.startUpdatingLocation()
        } else {
            print("Plase turn on location services and Gps")
        }
    }
    @IBAction func btnStartLocation(_ sender: Any) {
       locationManager.startUpdatingLocation()
    }
}
extension ViewController: CLLocationManagerDelegate{
   func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
//        print("\n Did UpDate Location:\(locations)")
         let region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: locations[0].coordinate.latitude, longitude: locations[0].coordinate.longitude), span: MKCoordinateSpan(latitudeDelta: 0.002, longitudeDelta: 0.002))
        self.mapView.setRegion(region, animated: true)
    }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
//        print("\n Did failed With Error:\(error.localizedDescription)")
        print("unable to aceess to your current location")
    }
}

