//
//  ViewController.swift
//  M-MapViewDemo
//
//  Created by agilemac-74 on 05/12/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit
import MapKit

class Artwork: NSObject,MKAnnotation{
    let title: String?
    let coordinate: CLLocationCoordinate2D
    
    init(title:String,coordinate:CLLocationCoordinate2D) {
        self.title = title
        self.coordinate = coordinate
        super.init()
    }
}
class ViewController: UIViewController {

    @IBOutlet var mapView: MKMapView!
    let RegionRedius: CLLocationDistance = 1000
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mapView.delegate = self
    }

    func centerMapOnLocation(Location:CLLocation){
        
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(Location.coordinate, RegionRedius, RegionRedius)
        mapView.setRegion(coordinateRegion, animated: true)
    }
    @IBAction func setRegionPressed(_ sender: Any) {
        let annotation = MKPointAnnotation()
        let centerCoordinate = CLLocationCoordinate2D(latitude: 22.407278, longitude: 73.18229444)
        annotation.coordinate = centerCoordinate
        annotation.title = "VADODARA 1"
        mapView.addAnnotation(annotation)
        
        centerMapOnLocation(Location: CLLocation(latitude: centerCoordinate.latitude, longitude: centerCoordinate.longitude))
        
    }
    
    @IBAction func testPressed(_ sender: Any) {
        
        let annotation = MKPointAnnotation()
        let centerCoordinate = CLLocationCoordinate2D(latitude: 22.427278, longitude: 73.18229444)
        annotation.coordinate = centerCoordinate
        annotation.title = "VADODARA "
        mapView.addAnnotation(annotation)
        
        centerMapOnLocation(Location: CLLocation(latitude: centerCoordinate.latitude, longitude: centerCoordinate.longitude))
        
    }
}
extension ViewController: MKMapViewDelegate{
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let identifier = "markar"
        var view:MKMarkerAnnotationView

        if let dequeuedView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)as? MKMarkerAnnotationView{
            dequeuedView.annotation = annotation
            view = dequeuedView
        }else{
            view = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            view.canShowCallout = true
            view.calloutOffset  = CGPoint(x: -5, y: 5)

            let tempView = UIView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
            tempView.backgroundColor = .red

            let tempView1 = UIView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
            tempView1.backgroundColor = .green

            view.rightCalloutAccessoryView = tempView
            view.leftCalloutAccessoryView = tempView1

        }
        return view
    }
}

