//
//  ViewController.swift
//  M-SqlLite Demo
//
//  Created by agilemac-74 on 03/12/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit
import SQLite3


class ViewController: UIViewController {
    @IBOutlet var txtId: UITextField!
    @IBOutlet var txtName: UITextField!
    @IBOutlet var txtChange: UITextField!
    var db : OpaquePointer?

    override func viewDidLoad() {
        super.viewDidLoad()
        openConnection()
//        createTable()
//        insertData()
//        fetchData()
        // Do any additional setup after loading the view, typically from a nib.
    }

    func openConnection(){
        let dirPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
        let dbPath = dirPath.appending("/MyDatabase.sqllite")
        
        if sqlite3_open(dbPath, &db) == SQLITE_OK{
            print("\n Database connected....:\(dbPath)")
        }else{
            print("Failed to create connection : \(getLatestError())")

        }
        
    }
    func createTable(){
        let query = "CREATE TABLE Person(id INT,name CHAR(225),address CHAR(255) )"
        
        var statement : OpaquePointer?
      
        if sqlite3_exec(db, query, nil, &statement, nil) == SQLITE_OK{
            print("\n Table Created")
        }else{
            print("\n failed to create table :\(getLatestError())")
        }
        
    }
    func getLatestError() -> String{
        return String.init(cString: sqlite3_errmsg(db))
        
    }
    func insertData(){
        let id = 1
        let number = 9662644378
        let name = txtName.text!
        let address = txtId.text!
        
        let query = "INSERT INTO Person(id, name, address, number) VALUES (\(id),'\(name)','\(address)','\(number)')"
        print("Insert Query : \(query)")
        var statement :OpaquePointer?
        
        if sqlite3_exec(db, query, nil, &statement, nil) == SQLITE_OK {
            print("\nInsert done")
        }else{
            print("\nFailed to insert record : \(getLatestError())")
        }
        
        sqlite3_finalize(statement)
    }
    func fetchData(){
        var queryStatement: OpaquePointer? = nil
        let queryStatementString = "SELECT * FROM Person;"
        
        if sqlite3_prepare_v2(db, queryStatementString, -1, &queryStatement, nil) == SQLITE_OK {
            
            print("Query Result:")
            
            while sqlite3_step(queryStatement) == SQLITE_ROW {
                
                let id = sqlite3_column_int(queryStatement, 0)
                
                let queryResultCol1 = sqlite3_column_text(queryStatement, 1)
                let name = String(cString: queryResultCol1!)
                
                let queryResultCol2 = sqlite3_column_text(queryStatement, 2)
                let address = String(cString: queryResultCol2!)
                
                
                print("\(id) | \(name) | \(address)")
            }
        } else {
            print("SELECT statement could not be prepared : \(getLatestError())")
        }
        sqlite3_finalize(queryStatement)
        
    }
    func  updateData(){
        
        let query = "UPDATE Person SET address = 'Mumbai' WHERE address = 'Ahmedabad'"
        var statement :OpaquePointer?
        if sqlite3_exec(db, query, nil, &statement, nil) == SQLITE_OK{
            print("\n Update Done")
        }else{
            print("\n Failed to Update record:\(getLatestError())")
        }
        sqlite3_finalize(statement)
    }
    func deleteData(){
        
        let query = "DELETE FROM Person WHERE ID = 1;"
        var statement :OpaquePointer?
        if sqlite3_exec(db, query, nil, &statement, nil) == SQLITE_OK{
            print("\n Delete Done")
        }else{
            print("\n Failed to Delete Record: \(getLatestError())")
        }
        sqlite3_finalize(statement)
    }
    
    func renameTable(){
        let query = "ALTER TABLE Person2 RENAME TO Person;"
        var statement :OpaquePointer?
        if sqlite3_exec(db, query, nil, &statement, nil) == SQLITE_OK{
            print("\n Rename Done")
        }else{
            print("\n Failed to Rename: \(getLatestError())")
            
        }
        
        sqlite3_finalize(statement)
    }
    
    func addColumn(){
       
        let query = "ALTER TABLE Person ADD COLUMN number INT"
        var statement :OpaquePointer?
        if sqlite3_exec(db, query, nil, &statement, nil) == SQLITE_OK{
            print("\n AddColumn Done")
        }else{
            print("\n Failed to AddColumn: \(getLatestError())")
        }
        sqlite3_finalize(statement)
    }
    
    @IBAction func btnInsert(_ sender: Any) {
        insertData()
    }
    
    @IBAction func btnUpDate(_ sender: Any) {
        updateData()
    }
    
    @IBAction func btnDelete(_ sender: Any) {
        deleteData()
    }
    
    @IBAction func btnFetchData(_ sender: Any) {
        fetchData()
    }
    
    @IBAction func btnRenameTable(_ sender: Any) {
       renameTable()
    }
    
    @IBAction func btnAddColumn(_ sender: Any) {
        addColumn()
    }
   
}

