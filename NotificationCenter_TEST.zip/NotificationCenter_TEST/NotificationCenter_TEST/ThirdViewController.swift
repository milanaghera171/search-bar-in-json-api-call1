//
//  ThirdViewController.swift
//  NotificationCenter_TEST
//
//  Created by agile-2 on 14/12/18.
//  Copyright © 2018 agile-2. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }


    
    @IBAction func btnPressed(_ sender: Any) {
        
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: NSNotification.Name.eventXYZ), object: self, userInfo: ["key1":"value1","key2":"value2"])
        
    }
    
}
