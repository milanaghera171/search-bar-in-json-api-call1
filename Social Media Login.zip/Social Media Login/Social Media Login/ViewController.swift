//
//  ViewController.swift
//  Social Media Login
//
//  Created by iOS TeamLead on 3/5/19.
//  Copyright © 2019 iOS TeamLead. All rights reserved.
//

import UIKit
import GoogleSignIn

class ViewController: UIViewController,GIDSignInUIDelegate{
    
    @IBOutlet weak var btnLogin: GIDSignInButton!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
         GIDSignIn.sharedInstance().uiDelegate = self

        
       
    }
   
    func sign(_ signIn: GIDSignIn!,
              present viewController: UIViewController!) {
        self.present(viewController, animated: true, completion: nil)
    }
    
    // Dismiss the "Sign in with Google" view
    func sign(_ signIn: GIDSignIn!,
              dismiss viewController: UIViewController!) {
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func btnLogin(_ sender: Any) {
        GIDSignIn.sharedInstance()?.signIn()
    }
    
}

