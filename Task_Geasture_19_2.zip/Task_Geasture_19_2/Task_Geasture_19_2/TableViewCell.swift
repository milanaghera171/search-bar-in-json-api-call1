//
//  TableViewCell.swift
//  Task_Geasture_19_2
//
//  Created by iOS TeamLead on 2/19/19.
//  Copyright © 2019 iOS TeamLead. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var lblName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
