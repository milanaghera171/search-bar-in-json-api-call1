//
//  ViewController.swift
//  Task_Geasture_19_2
//
//  Created by iOS TeamLead on 2/19/19.
//  Copyright © 2019 iOS TeamLead. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIGestureRecognizerDelegate {

    @IBOutlet weak var tblView: UITableView!
     var titalArr = ["aa","c","d","aa","ddd","aa","c","d","aa","ddd","aa","c","d","aa","ddd"]
    var titalArr1 = ["asssssa","csssdd","ddffffg","aa","ddd","aagffggdf","c","d","aa","dgfgfgfdd","aa","c","d","aa","ddgffggfdfd"]
   var titalArr2 = ["aa","c","d","aaggfg","ddd","gfgfgfdaa","c","dgfgf","aa","ddgfdgdfgd","aa","c","d"]
    override func viewDidLoad() {
        super.viewDidLoad()
       gesture()
    }
    
    func gesture(){
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture(gesture:)))
        swipeRight.direction = UISwipeGestureRecognizerDirection.right
        self.view.addGestureRecognizer(swipeRight)
        
        let swipeDown = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture(gesture:)))
        swipeDown.direction = UISwipeGestureRecognizerDirection.left
        self.view.addGestureRecognizer(swipeDown)
    }
    
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            
            
            switch swipeGesture.direction {
            case UISwipeGestureRecognizerDirection.right:
                value = 0
                tblView.reloadData()
                
                print("Swiped right")
            case UISwipeGestureRecognizerDirection.down:
                print("Swiped down")
            case UISwipeGestureRecognizerDirection.left:
                value = 2
                tblView.reloadData()
                print("Swiped left")
            case UISwipeGestureRecognizerDirection.up:
                print("Swiped up")
            default:
                break
            }
        }
    }
var value = 2


    @IBAction func btn1(_ sender: Any) {
        
     value = 0
        tblView.reloadData()
    }
    @IBAction func btn2(_ sender: Any) {
        value = 1
        tblView.reloadData()
        
    }
    @IBAction func btn3(_ sender: Any) {
        value = 2
       tblView.reloadData()
    }
    
}
// Mark :- Table View dataSource
extension ViewController:UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch (value) {
        case 0:
            return titalArr.count
        case 1:
            return titalArr1.count
        case 2:
            return titalArr2.count
        default:
             return titalArr.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? TableViewCell
       cell?.lblName.text = titalArr[indexPath.row]
        
        
        
        switch (value) {
        case 0:
            cell?.lblName.text = titalArr[indexPath.row]
            
            
        case 1:
            cell?.lblName.text = titalArr1[indexPath.row]
            
        case 2:
            cell?.lblName.text = titalArr2[indexPath.row]
       
        default:
            cell?.lblName.text = titalArr[indexPath.row]
        }
        
        return cell!
    }
   
}
extension ViewController:UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
        
    }
    
}
