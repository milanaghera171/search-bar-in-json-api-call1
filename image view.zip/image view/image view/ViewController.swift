//
//  ViewController.swift
//  image view
//
//  Created by pc on 9/18/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    @IBOutlet var searchbar: UISearchBar!
    @IBOutlet var UItable: UITableView!
    
   var array1 = ["AAA","BBB","CCC","DDD","EEE","CCC","DDD","EEE","FFF","GGG","HHH","III","JJJ","KKK","LLL","MMM","NNN","OOO","PPP","QQQQ","RRR","AAA","BBB","CCC","DDD","EEE","CCC","DDD","EEE","FFF","GGG","HHH","III","JJJ","KKK","LLL","MMM","NNN","OOO","PPP","QQQQ","RRR"]
    var array2 = ["aaa","bbb","ccc","ddd","eee","fff","ggg","hhh","iii","jjj","kkk","lll","mmm","nnn","ooo","ppp","qqq","rrr","aaa","bbb","ccc","ddd","eee","fff","ggg","hhh","iii","jjj","kkk","lll","mmm","nnn","ooo","ppp","qqq","rrr"]
    
    var arrimg = [#imageLiteral(resourceName: "images (3)"),#imageLiteral(resourceName: "images (2)"),#imageLiteral(resourceName: "images (3)"),#imageLiteral(resourceName: "download (1)"),#imageLiteral(resourceName: "images (2)"),#imageLiteral(resourceName: "images"),#imageLiteral(resourceName: "images (1)"),#imageLiteral(resourceName: "images (4)"),#imageLiteral(resourceName: "images"),#imageLiteral(resourceName: "images (4)"),#imageLiteral(resourceName: "images (1)"),#imageLiteral(resourceName: "images (2)"),#imageLiteral(resourceName: "images (3)"),#imageLiteral(resourceName: "images (4)"),#imageLiteral(resourceName: "images"),#imageLiteral(resourceName: "images (1)"),#imageLiteral(resourceName: "images (2)"),#imageLiteral(resourceName: "images (3)"),#imageLiteral(resourceName: "images (4)"),#imageLiteral(resourceName: "images (3)"),#imageLiteral(resourceName: "images (2)"),#imageLiteral(resourceName: "images (3)"),#imageLiteral(resourceName: "download (1)"),#imageLiteral(resourceName: "images (2)"),#imageLiteral(resourceName: "images"),#imageLiteral(resourceName: "images (1)"),#imageLiteral(resourceName: "images (4)"),#imageLiteral(resourceName: "images"),#imageLiteral(resourceName: "images (4)"),#imageLiteral(resourceName: "images (1)"),#imageLiteral(resourceName: "images (2)"),#imageLiteral(resourceName: "images (3)"),#imageLiteral(resourceName: "images (4)"),#imageLiteral(resourceName: "images"),#imageLiteral(resourceName: "images (1)"),#imageLiteral(resourceName: "images (2)"),#imageLiteral(resourceName: "images (3)"),#imageLiteral(resourceName: "images (4)")]
    var searchName = [String]()
    var searching = false
    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchbar.delegate = self
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searching{
         return searchName.count
        }else{
        return array1.count
    }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:TableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        if searching {
            cell.lbl1.text = searchName[indexPath.row]
        }else{
            cell.lbl1.text = array1[indexPath.row]
            cell.lbl2.text = array2[indexPath.row]
            cell.img.image = arrimg[indexPath.row]
        }
       
        return cell
        
    }
        /*let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        cell?.textLabel?.text = array1[indexPath.row]
        cell?.detailTextLabel?.text = array2[indexPath.row]
        return cell!*/
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detail:DetailViewController =
           
           self.storyboard?.instantiateViewController(withIdentifier:"DetailViewController") as!DetailViewController
        
        detail.strlbl1 = array1[indexPath.row]
        detail.strlbl2 = array2[indexPath.row]
        detail.strimg = arrimg[indexPath.row]
       
        
          self.navigationController?.pushViewController(detail, animated: true)
        
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            
            array1.remove(at: indexPath.row)
            array2.remove(at: indexPath.row)
            arrimg.remove(at: indexPath.row)
            
            UItable.deleteRows(at:[indexPath], with: .fade)
            
        }
        
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        // set initial cell
        cell.alpha = 0
        let transform = CATransform3DTranslate(CATransform3DIdentity, -400, 20, 0)
        cell.layer.transform = transform
        //Final set cell animation
        UIView.animate(withDuration: 1.0){
            cell.alpha = 1.0
            cell.layer.transform = CATransform3DIdentity
            
        }
        
    }
}
//extension ViewController:UISearchBarDelegate{
//    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
//
//        if searchBar.text == nil || searchBar.text == ""{
//            searching = false
//            view.endEditing(true)
//
//        }else{
//            searching = true
//            searchName = array1.filter({$0.prefix( searchText.count) == searchText})
//
//
//        }
//
//        //        searchCountry = arrModelCountrys.filter({$0.name.prefix( searchText.count) == searchText})
//        //        searching = true
//        UItable.reloadData()
//    }
//
//}

extension ViewController:UISearchBarDelegate{
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        searchName = array1.filter({$0.prefix(searchText.count) == searchText})
        searching = true
        UItable.reloadData()
    }
}

