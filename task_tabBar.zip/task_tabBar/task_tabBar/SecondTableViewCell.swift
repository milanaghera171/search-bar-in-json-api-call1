//
//  SecondTableViewCell.swift
//  task_tabBar
//
//  Created by iOS TeamLead on 2/26/19.
//  Copyright © 2019 iOS TeamLead. All rights reserved.
//

import UIKit

class SecondTableViewCell: UITableViewCell {

    @IBOutlet weak var mView1: UIView!
      @IBOutlet weak var mView2: UIView!
      @IBOutlet weak var mView3: UIView!
      @IBOutlet weak var mView4: UIView!
      @IBOutlet weak var mView5: UIView!
      @IBOutlet weak var mView6: UIView!
      @IBOutlet weak var mView7: UIView!
      @IBOutlet weak var mView8: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
