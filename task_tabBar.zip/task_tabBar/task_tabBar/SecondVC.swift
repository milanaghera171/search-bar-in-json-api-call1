//
//  SecondVC.swift
//  task_tabBar
//
//  Created by iOS TeamLead on 2/26/19.
//  Copyright © 2019 iOS TeamLead. All rights reserved.
//

import UIKit

class SecondVC: UIViewController {
    @IBOutlet weak var tblVC: UITableView!
    var Myarr = ["aaaa","bbb"]
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    

    
}
extension SecondVC:UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Myarr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SecondTableViewCell", for: indexPath) as? SecondTableViewCell
        return (cell ?? nil)!
    
    }
    
    
   
}
extension SecondVC:UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 700
    }
}
