//
//  ViewController.swift
//  task_tabBar
//
//  Created by iOS TeamLead on 2/18/19.
//  Copyright © 2019 iOS TeamLead. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var img3: UIImageView!
    
    @IBOutlet weak var tblView: UITableView!
    
    @IBOutlet weak var viewHeight: NSLayoutConstraint!
    @IBOutlet weak var cellView: UIView!
    @IBOutlet weak var btnAdd: UIButton!
    @IBOutlet weak var view1: UIView!
    var imgArr = [#imageLiteral(resourceName: "images (2)"),#imageLiteral(resourceName: "images (3)"),#imageLiteral(resourceName: "images (1)"),#imageLiteral(resourceName: "images (1)"),#imageLiteral(resourceName: "images (4)"),#imageLiteral(resourceName: "images (2)"),#imageLiteral(resourceName: "images (3)"),#imageLiteral(resourceName: "images (1)"),#imageLiteral(resourceName: "images (1)"),#imageLiteral(resourceName: "images (4)")]
    var titalArr = ["Minimal Photobook","Tour Photobook","Minimal Photobook","Tour Photobook","Minimal Photobook","Tour Photobook","Minimal Photobook","Tour Photobook","Minimal Photobook","Tour Photobook"]
    override func viewDidLoad() {
        super.viewDidLoad()
       img3.layer.cornerRadius = img3.frame.size.width/2
      view1.isHidden = true
       viewHeight.constant = 0
    }

    @IBAction func btnAds(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        
        if btnAdd.isSelected == true{
            viewHeight.constant = 95
            view1.isHidden = false
        }else{
            view1.isHidden = true
            viewHeight.constant = 0
        }
    
    
    }
}
extension ViewController:UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titalArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? TableViewCell
        cell?.lblTital.text = titalArr[indexPath.row]
        cell?.imgView.image = imgArr[indexPath.row]
       
        return cell!
    }

}
extension ViewController:UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 175
        
    }
    
}
