//
//  CategoryRow.swift
//  task_tableview in collectionview
//
//  Created by iOS TeamLead on 2/16/19.
//  Copyright © 2019 iOS TeamLead. All rights reserved.
//

import UIKit

class CategoryRow: UITableViewCell {
 @IBOutlet weak var collectionView: UICollectionView!
    let imgArr = [#imageLiteral(resourceName: "download (4)"),#imageLiteral(resourceName: "download (1)"),#imageLiteral(resourceName: "download (2)"),#imageLiteral(resourceName: "download (3)"),#imageLiteral(resourceName: "download (5)"),#imageLiteral(resourceName: "images"),#imageLiteral(resourceName: "download"),#imageLiteral(resourceName: "download (1)"),#imageLiteral(resourceName: "download (2)"),#imageLiteral(resourceName: "download (4)"),#imageLiteral(resourceName: "download (3)"),#imageLiteral(resourceName: "download (5)"),#imageLiteral(resourceName: "images"),#imageLiteral(resourceName: "download"),#imageLiteral(resourceName: "download (1)"),#imageLiteral(resourceName: "download (4)"),#imageLiteral(resourceName: "download (2)"),#imageLiteral(resourceName: "download (3)"),#imageLiteral(resourceName: "download (5)"),#imageLiteral(resourceName: "images"),#imageLiteral(resourceName: "download (4)"),#imageLiteral(resourceName: "download (4)"),#imageLiteral(resourceName: "download (1)"),#imageLiteral(resourceName: "download (2)"),#imageLiteral(resourceName: "download (3)"),#imageLiteral(resourceName: "download (5)"),#imageLiteral(resourceName: "images"),#imageLiteral(resourceName: "download"),#imageLiteral(resourceName: "download (1)"),#imageLiteral(resourceName: "download (2)"),#imageLiteral(resourceName: "download (4)"),#imageLiteral(resourceName: "download (3)"),#imageLiteral(resourceName: "download (5)"),#imageLiteral(resourceName: "images"),#imageLiteral(resourceName: "download"),#imageLiteral(resourceName: "download (1)"),#imageLiteral(resourceName: "download (4)"),#imageLiteral(resourceName: "download (2)"),#imageLiteral(resourceName: "download (3)"),#imageLiteral(resourceName: "download (5)"),#imageLiteral(resourceName: "images"),#imageLiteral(resourceName: "download (4)"),]

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    
}

    

extension CategoryRow : UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imgArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "videoCell", for: indexPath)as! VideoCell
        cell.imageView.image = imgArr[indexPath.row]
        return cell
    }
   
}
extension CategoryRow : UICollectionViewDelegateFlowLayout {
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
        let itemsPerRow:CGFloat = 4
        let hardCodedPadding:CGFloat = 5
        let itemWidth = (collectionView.bounds.width / itemsPerRow) - hardCodedPadding
        let itemHeight = collectionView.bounds.height - (2 * hardCodedPadding)
        return CGSize(width: itemWidth, height: itemHeight)
        
}
}
