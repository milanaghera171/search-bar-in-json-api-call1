//
//  VideoCell.swift
//  task_tableview in collectionview
//
//  Created by iOS TeamLead on 2/16/19.
//  Copyright © 2019 iOS TeamLead. All rights reserved.
//

import UIKit

class VideoCell: UICollectionViewCell {
     @IBOutlet weak var imageView: UIImageView!
}
